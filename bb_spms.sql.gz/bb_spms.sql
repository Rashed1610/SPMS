-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2017 at 06:00 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bb_spms`
--

-- --------------------------------------------------------

--
-- Table structure for table `berth`
--

CREATE TABLE `berth` (
  `Berth_Id` varchar(15) NOT NULL,
  `Quay_Id` varchar(15) DEFAULT NULL,
  `Berth_Name` varchar(50) DEFAULT NULL,
  `Berth_Length` int(10) DEFAULT NULL,
  `Berth_Depth` decimal(10,2) DEFAULT NULL,
  `Berth_S_Pos` int(10) DEFAULT NULL,
  `Berth_E_Pos` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berth`
--

INSERT INTO `berth` (`Berth_Id`, `Quay_Id`, `Berth_Name`, `Berth_Length`, `Berth_Depth`, `Berth_S_Pos`, `Berth_E_Pos`) VALUES
('B120', 'Q112', 'North-1', 50, '12.00', 1, 15);

-- --------------------------------------------------------

--
-- Table structure for table `berth_allocation`
--

CREATE TABLE `berth_allocation` (
  `Berth_Alloc_Id` varchar(15) NOT NULL,
  `Visit_Id` varchar(30) NOT NULL,
  `Berth_Id` varchar(15) DEFAULT NULL,
  `Alloc_S_Time` datetime DEFAULT NULL,
  `Alloc_E_Time` datetime DEFAULT NULL,
  `State` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berth_allocation`
--

INSERT INTO `berth_allocation` (`Berth_Alloc_Id`, `Visit_Id`, `Berth_Id`, `Alloc_S_Time`, `Alloc_E_Time`, `State`) VALUES
('BA110', 'VI111', 'B120', '2017-05-10 08:30:30', '2017-05-11 08:40:30', 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `cargo`
--

CREATE TABLE `cargo` (
  `Cargo_Id` varchar(15) NOT NULL,
  `Vessel_Id` varchar(15) NOT NULL,
  `Cargo_Name` varchar(25) DEFAULT NULL,
  `Cargo_Type` varchar(25) DEFAULT NULL,
  `Cargo_Size` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cargo`
--

INSERT INTO `cargo` (`Cargo_Id`, `Vessel_Id`, `Cargo_Name`, `Cargo_Type`, `Cargo_Size`) VALUES
('C1100', 'V10A', 'V1100-120', 'Food', 50),
('C1102', 'V10A', 'C1100-122', 'WASTE', 20);

-- --------------------------------------------------------

--
-- Table structure for table `em_info`
--

CREATE TABLE `em_info` (
  `Em_ID` int(11) NOT NULL,
  `Em_Name` varchar(30) DEFAULT NULL,
  `Em_Sex` varchar(10) DEFAULT NULL,
  `Em_Con_no` int(11) DEFAULT NULL,
  `Em_Email` varchar(50) NOT NULL,
  `Em_Add` varchar(40) DEFAULT NULL,
  `Em_Dept` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `em_info`
--

INSERT INTO `em_info` (`Em_ID`, `Em_Name`, `Em_Sex`, `Em_Con_no`, `Em_Email`, `Em_Add`, `Em_Dept`) VALUES
(16103210, 'Md Rashaduzzaman', 'Male', 1515297427, 'rashaduzzaman@gmail.com', 'Dhaka', 'Management'),
(16103238, 'Almas Nakib', 'Male', 1521535878, 'nakb@gmail.com', 'Dhaka', 'Management');

-- --------------------------------------------------------

--
-- Table structure for table `port`
--

CREATE TABLE `port` (
  `Port_Id` varchar(15) NOT NULL,
  `Port_Name` varchar(50) DEFAULT NULL,
  `Port_Description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `port`
--

INSERT INTO `port` (`Port_Id`, `Port_Name`, `Port_Description`) VALUES
('P10', 'Mongla Port', 'on the bank of Pashur River,48 km south of Khulna and 70 nautical miles from the Bay of Bengal'),
('P20', 'Chittagong port', 'Karnafuli');

-- --------------------------------------------------------

--
-- Table structure for table `quay`
--

CREATE TABLE `quay` (
  `Quay_Id` varchar(15) NOT NULL,
  `Port_Id` varchar(15) NOT NULL,
  `Quay_Name` varchar(50) DEFAULT NULL,
  `Quay_Length` int(15) DEFAULT NULL,
  `Quay_Description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quay`
--

INSERT INTO `quay` (`Quay_Id`, `Port_Id`, `Quay_Name`, `Quay_Length`, `Quay_Description`) VALUES
('Q111', 'P10', 'ICT', 150, 'empty'),
('Q112', 'P10', 'HEx', 150, 'empty');

-- --------------------------------------------------------

--
-- Table structure for table `vessel_info`
--

CREATE TABLE `vessel_info` (
  `Vessel_Id` varchar(8) NOT NULL,
  `Vessel_Name` varchar(30) NOT NULL,
  `Vessel_Call_sign` varchar(20) DEFAULT NULL,
  `Vessel_Length` varchar(20) DEFAULT NULL,
  `Vessel_flag` varchar(20) NOT NULL,
  `Vessel_Type` varchar(50) NOT NULL,
  `Vessel_Beam` decimal(10,2) NOT NULL,
  `Vessel_Depth` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vessel_info`
--

INSERT INTO `vessel_info` (`Vessel_Id`, `Vessel_Name`, `Vessel_Call_sign`, `Vessel_Length`, `Vessel_flag`, `Vessel_Type`, `Vessel_Beam`, `Vessel_Depth`) VALUES
('V10A', 'KOTA HALUS', '', '120ft', 'HK', 'CARGO', '120.00', '50.00'),
('V10B', 'Rustom', '', '120ft', 'BD', 'CARGO', '80.00', '50.00');

-- --------------------------------------------------------

--
-- Table structure for table `visit`
--

CREATE TABLE `visit` (
  `Visit_Id` varchar(15) NOT NULL,
  `Vessel_Id` varchar(15) DEFAULT NULL,
  `ETA` datetime DEFAULT NULL,
  `ETD` datetime DEFAULT NULL,
  `ATA` datetime DEFAULT NULL,
  `ATD` datetime DEFAULT NULL,
  `Visit_Note` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visit`
--

INSERT INTO `visit` (`Visit_Id`, `Vessel_Id`, `ETA`, `ETD`, `ATA`, `ATD`, `Visit_Note`) VALUES
('VI111', 'V10A', '2017-05-05 08:30:55', '0000-00-00 00:00:00', '2017-05-06 12:30:55', '0000-00-00 00:00:00', 'Berthed'),
('VI112', 'V10B', '2017-10-10 12:20:22', '2017-10-20 12:20:35', '2017-10-10 15:20:22', '2017-10-20 21:20:22', 'Departed');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berth`
--
ALTER TABLE `berth`
  ADD PRIMARY KEY (`Berth_Id`),
  ADD KEY `Quay_Id` (`Quay_Id`);

--
-- Indexes for table `berth_allocation`
--
ALTER TABLE `berth_allocation`
  ADD PRIMARY KEY (`Berth_Alloc_Id`),
  ADD KEY `Visit_Id` (`Visit_Id`),
  ADD KEY `Berth_Id` (`Berth_Id`);

--
-- Indexes for table `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`Cargo_Id`),
  ADD KEY `Vessel_Id` (`Vessel_Id`);

--
-- Indexes for table `em_info`
--
ALTER TABLE `em_info`
  ADD PRIMARY KEY (`Em_ID`);

--
-- Indexes for table `port`
--
ALTER TABLE `port`
  ADD PRIMARY KEY (`Port_Id`);

--
-- Indexes for table `quay`
--
ALTER TABLE `quay`
  ADD PRIMARY KEY (`Quay_Id`),
  ADD KEY `Port_Id` (`Port_Id`);

--
-- Indexes for table `vessel_info`
--
ALTER TABLE `vessel_info`
  ADD PRIMARY KEY (`Vessel_Id`);

--
-- Indexes for table `visit`
--
ALTER TABLE `visit`
  ADD PRIMARY KEY (`Visit_Id`),
  ADD KEY `Vessel_Id` (`Vessel_Id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `berth`
--
ALTER TABLE `berth`
  ADD CONSTRAINT `berth_ibfk_1` FOREIGN KEY (`Quay_Id`) REFERENCES `quay` (`Quay_Id`) ON UPDATE CASCADE;

--
-- Constraints for table `berth_allocation`
--
ALTER TABLE `berth_allocation`
  ADD CONSTRAINT `berth_allocation_ibfk_3` FOREIGN KEY (`Visit_Id`) REFERENCES `visit` (`Visit_Id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `berth_allocation_ibfk_4` FOREIGN KEY (`Berth_Id`) REFERENCES `berth` (`Berth_Id`) ON UPDATE CASCADE;

--
-- Constraints for table `cargo`
--
ALTER TABLE `cargo`
  ADD CONSTRAINT `cargo_ibfk_1` FOREIGN KEY (`Vessel_Id`) REFERENCES `vessel_info` (`Vessel_Id`) ON UPDATE CASCADE;

--
-- Constraints for table `quay`
--
ALTER TABLE `quay`
  ADD CONSTRAINT `quay_ibfk_1` FOREIGN KEY (`Port_Id`) REFERENCES `port` (`Port_Id`) ON UPDATE CASCADE;

--
-- Constraints for table `visit`
--
ALTER TABLE `visit`
  ADD CONSTRAINT `visit_ibfk_1` FOREIGN KEY (`Vessel_Id`) REFERENCES `vessel_info` (`Vessel_Id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
